const Env = use('Env')

{
    googlemaps: {
      key: Env.get('GOOGLE_MAP_KEY')
    }
  }